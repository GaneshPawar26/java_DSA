import java.util.Scanner;


class First
{
    public static void main(String []args)
    {
        String s1;
        String s2;

        Scanner sc=new Scanner(System.in);

        s1=sc.nextLine();
        s2=sc.nextLine();

        System.out.println(s1 + s2);

        
    }
}