//push at the Bottom of the stack
//hint- most of the stack problem can be solved by recursion

import java.util.Stack;


class C
{
    public static void main(String []args)
    {
        Stack<Integer> s1=new Stack<>();

        s1.push(10);
        s1.push(20);
        s1.push(30);
        s1.push(40);
        s1.push(50);




        System.out.println(s1);


    }
}
