// deque is a double ended queue 

//very usefull data structure


//with deque we can easily implement stack and queue

// METHODS=
// addFirst()
// addLast()
// removeFirst()
// removeLast()
// getFirst() same as peek() of queue
// getLast()





// import java.util.*;

// class A
// {
//     public static void main(String []args)
//     {
//         Queue<Integer> q=new LinkedList<>();

//         q.add(10);
//         q.add(20);
//         q.add(40);
//         q.add(70);

//         System.out.println(q);
//         System.out.println(q.remove(20));
//         System.out.println(q);


//     }
// }