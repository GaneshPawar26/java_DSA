import java.util.Scanner;



class First
{
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number plz");
        int n=sc.nextInt();

        System.out.println(n);

        sc.close();
    }
}