import java.util.Scanner;


class Permutation
{


    public static void sol(String name)
    {
        
        
    }
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the String");

        String s=sc.nextLine();
    }
}